import os
from pathlib import Path

dirpath = "./Results"
paths = sorted(Path(dirpath).iterdir(), key=os.path.getmtime)
# print(paths)

paths = paths[:-40]


paths = [str(i) for i in paths]

paths = [each_path[8:] for each_path in paths]

for each_path in paths:
	print((each_path))

f = open('all_trends.txt', 'r')
queries = f.readlines()
f.close()

# print(queries)

updated_queries = [b for b in queries if
          all(a not in b for a in paths)] 


for each_q in updated_queries:
	print(str(each_q))

with open('updated_queries.txt', 'w') as filehandle:
    for listitem in updated_queries:
        filehandle.write(listitem)